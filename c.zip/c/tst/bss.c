#include <stdio.h>

int var;

int main(void) {
   printf("var=%d\n", var);
   return 0;
}
