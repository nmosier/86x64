void func(void) {}

void (*ptr)(void) = func;

int main(void) {
   ptr();
   return 0;
}
