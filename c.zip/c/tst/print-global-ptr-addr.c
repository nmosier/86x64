#include <stdio.h>

void func(void) {
   printf("func @ %p\n", (void *) func);
}

void (*ptr)(void) = func;

int main(void) {
   ptr();
   return 0;
}
