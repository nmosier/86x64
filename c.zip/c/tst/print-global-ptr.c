#include <stdio.h>

void func(void) {
   printf("func called\n");
}

void (*ptr)(void) = func;

int main(void) {
   ptr();
   return 0;
}
