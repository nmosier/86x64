#include <stdio.h>

int main(void) {
   printf("%p\n", (void *) main);
   return 0;
}
