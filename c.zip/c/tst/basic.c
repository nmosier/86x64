int var = 42;

int main(void) {
   return 2;
}
