#include "macho.h"
#include "macho-template.h"

int decl(macho_build_symtab)(struct SYMTAB *symtab, struct build_info *info);
                             
#include "macho-template.h"
