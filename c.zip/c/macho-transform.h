#include "macho.h"

int macho_transform_archive_32to64(const struct archive_32 *archive32,
                                   struct archive_64 *archive64);

